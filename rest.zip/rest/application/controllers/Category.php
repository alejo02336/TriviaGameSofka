<?php
use chriskacerguis\RestServer\RestController;
require APPPATH . '/libraries/RestController.php';
require APPPATH . '/libraries/Format.php';
defined('BASEPATH') OR exit('No direct script access allowed');



class Category extends RestController {
    public function __construct() {
        parent::__construct();

        $this->load->database();
        $this->load->model('Categories');
        $this->load->helper('url');
    }

    public function categories_get() {

        $this->response($this->Categories->findAll());
    }

    public function save_post(){
        $json = file_get_contents('php://input');
        $obj = json_decode($json, TRUE);


        $this->response($this->Categories->saveCategory($obj));
    }

    public function delete_post(){
        $json = file_get_contents('php://input');
        $obj = json_decode($json, TRUE);


        $this->response($this->Categories->deleteCategory($obj));
    }
}