<?php
use chriskacerguis\RestServer\RestController;
require APPPATH . '/libraries/RestController.php';
require APPPATH . '/libraries/Format.php';
defined('BASEPATH') OR exit('No direct script access allowed');



class Question extends RestController {
    public function __construct() {
        parent::__construct();

        $this->load->database();
        $this->load->model('Questions');
        $this->load->helper('url');
    }

    public function save_post(){
        $json = file_get_contents('php://input');
        $obj = json_decode($json, TRUE);


        $this->response($this->Questions->saveQuestion($obj));
    }

    public function saveop_post(){
        $json = file_get_contents('php://input');
        $obj = json_decode($json, TRUE);
        $this->response($this->Questions->saveOption($obj));

    }

    public function question_get(){
        $json = file_get_contents('php://input');
        $obj = json_decode($json, TRUE);

        $this->response($this->Questions->getQuestion($obj));


        $json = file_get_contents('php://input');
    }

    public function borrar_post(){
	   $json = file_get_contents('php://input');
	   $obj = json_decode($json, TRUE);

	   $text = $obj['text'];

		//Define your host here.
		$hostname = "localhost";

		//Define your database User Name here.
		$username = "foodh100_root";

		//Define your database Password here.
		$password = "Bl8p+ng=KmTb";

		//Define your Database Name here.
		$dbname = "foodh100_quiz";

		//Creas una variable de tipo objeto mysqli con los datos de la bd y el charset que quieras

		$conn = mysqli_connect($hostname, $username, $password);


		mysqli_select_db( $conn, $dbname);


		// Type your website name or domain name here.
		$domain_name = "https://fused-routes.000webhostapp.com/rest/" ;










			// Inserting data into MySQL database.
			mysqli_query($conn, "DELETE FROM `questions` WHERE text = '{$text}'");

			$MESSAGE = "Borrado";

			// Printing response message on screen after successfully inserting the image .
			echo json_encode($text);




	   //$this->response($this->Users->borrar($obj));


   }



}