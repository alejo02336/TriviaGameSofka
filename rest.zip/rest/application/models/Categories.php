<?php

Class Categories extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();

    }

    public function findAll(){

        $this->db->select();
        $this->db->from('categories');

        $query = $this->db->get();

        return $query->result();


    }

    public function saveCategory($obj){
        $name = $obj['name'];
        $level = $obj['level'];
        $query = $this->db->query("INSERT INTO `categories` (name, level) VALUES ('{$name}', '{$level}')");
        return 'insertado';
    }

    public function deleteCategory($obj){
        $name = $obj['name'];
        $level = $obj['level'];

        $this->db->where('name', $name);
        $this->db->delete('categories');


        return $query->result();
    }

}