<?php

Class Questions extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();

    }

    public function saveQuestion($obj){
        $text = $obj['text'];
        $category = $obj['category'];
        $query = $this->db->query("INSERT INTO `questions` (text, category) VALUES ('{$text}', '{$category}')");
        return 'insertado';
    }

      public function saveOption($obj){
        $text = $obj['text'];
        $value = $obj['value'];
        $question = $obj['question'];
        $query = $this->db->query("INSERT INTO `options` (text, value, question) VALUES ('{$text}', '{$value}','{$question}')");
        return 'insertado';
    }

    public function getQuestion($obj){
        $query = $this->db->query("SELECT a.*, d.*, c.* FROM questions a, options d, categories c INNER JOIN d ON a.text = d.question INNER JOIN d ON a.category = c.name ORDER BY c.level");
        return $query->result();
    }

    public function delQuestion($obj){
        $text = $obj['text'];
        $category = $obj['category'];
        $this->db->where('text', 'asdasd');
        $this->db->delete('questions');


        return $query->result();
    }

}