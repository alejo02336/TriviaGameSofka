<?php

Class Users extends CI_Model {


    public function __construct() {
        parent::__construct();
        $this->load->database();

    }



    public function findAll(){

        $this->db->select();
        $this->db->from('records');

        $query = $this->db->get();

        return $query->result();


    }


}