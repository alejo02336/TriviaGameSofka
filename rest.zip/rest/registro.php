<?php

	//Define your host here.
	$hostname = "localhost";

	//Define your database User Name here.
	$username = "root";

	//Define your database Password here.
	$password = "";

	//Define your Database Name here.
	$dbname = "parkit";

    //Creas una variable de tipo objeto mysqli con los datos de la bd y el charset que quieras
 
	$conn = mysqli_connect($hostname, $username, $password);
    
	
	mysqli_select_db( $conn, $dbname);
    
 
	// Type your website name or domain name here.
	$domain_name = "http://192.168.1.8/rest/" ;
	
	// Image uploading folder.
	$target_dir = "uploads";
	
	// Generating random image name each time so image name will not be same .
	$target_dir = $target_dir . "/" .rand() . "_" . time() . ".jpeg";
	
	// Receiving image tag sent from application.
	$img_tag = $_POST["image_tag"];
	
	// Receiving image sent from Application	
	if(move_uploaded_file($_FILES['image']['tmp_name'], $target_dir)){
		
		// Adding domain name with image random name.
		$target_dir = $domain_name . $target_dir ;
		
		// Inserting data into MySQL database.
		mysqli_query($conn, "insert into parqueadero ( descripcion, latitud, longitud, direccion, precio, categoria, foto,  horario, ciudad, correo, telefono) VALUES('hola' , 'hola', 'hola', 'hola', 'hola', 'hola', '$target_dir',  'hola', 'hola', 'danny.martinez@uao.edu.co', 'hola'  )");
		
		$MESSAGE = "Image Uploaded Successfully." ;
			
		// Printing response message on screen after successfully inserting the image .	
		echo json_encode($MESSAGE);
	}


?>